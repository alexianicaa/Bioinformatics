import numpy as np
import matplotlib.pyplot as plt
from collections import Counter
from typing import List, Tuple

def cg_content(seq: str) -> float:
    """Compute C+G percentage"""
    return (seq.count('C') + seq.count('G')) / len(seq) * 100

def kappa_ic(seq: str) -> float:
    """Compute Kappa Index of Coincidence (IC)"""
    counts = Counter(seq)
    N = len(seq)
    if N <= 1:
        return 0
    return sum(v*(v-1) for v in counts.values()) / (N*(N-1)) * 100

def center_of_weight(seq: str) -> float:
    """Compute weighted center based on C+G content"""
    positions = np.arange(len(seq))
    weights = np.array([1 if nt in 'CG' else 0 for nt in seq])
    if weights.sum() == 0:
        return len(seq)/2
    return (positions * weights).sum() / weights.sum()

def sliding_window(sequence: str, window: int) -> Tuple[List[float], List[float]]:
    """Compute sliding window C+G% and IC"""
    cg_vals, ic_vals = [], []
    for i in range(len(sequence) - window + 1):
        w = sequence[i:i+window]
        cg_vals.append(cg_content(w))
        ic_vals.append(kappa_ic(w))
    return cg_vals, ic_vals

def dna_pattern(sequence: str, window: int = 30, title: str = "DNA Pattern"):
    """Generate DNA pattern plot with C+G% vs IC and center"""
    cg_vals, ic_vals = sliding_window(sequence, window)
    center = center_of_weight(sequence)
    
    fig, axs = plt.subplots(1, 2, figsize=(14,6))
    
    axs[0].scatter(cg_vals, ic_vals, c='blue', edgecolor='k', s=80)
    axs[0].set_xlabel('C+G%')
    axs[0].set_ylabel('Kappa Index of Coincidence (IC)')
    axs[0].set_title(f"{title}: C+G% vs IC")
    axs[0].grid(True)
    
    axs[1].scatter([1], [center], c='red', edgecolor='k', s=200)
    axs[1].set_xlim(0, 2)
    axs[1].set_ylabel('Center of Weight (bp)')
    axs[1].set_title(f"{title}: Center of Weight")
    axs[1].set_xticks([])
    axs[1].grid(True)
    
    plt.tight_layout()
    plt.show()
    
    print(f"Sequence length: {len(sequence)}")
    print(f"Number of windows: {len(cg_vals)}")
    print(f"Whole-sequence C+G%: {cg_content(sequence):.2f}")
    print(f"Whole-sequence IC: {kappa_ic(sequence):.2f}")
    print(f"Center of Weight (bp): {center:.2f}\n")

if __name__ == "__main__":
    S = "CGGACTGATCTATCTAAAAAAAAAAAAAAAAAAAAAAAAAAACGTAGCATCTATCGATCTATCTAGCGATCTATCTACTACG"
    promoter_seq = "ATGCGCGATCGATCGATCGCGCGATATATATATCGCGCGATCGATCGATCGCGCGATCGATCG"
    
    dna_pattern(S, window=30, title="Test Sequence S")
    dna_pattern(promoter_seq, window=30, title="Promoter Sequence")
