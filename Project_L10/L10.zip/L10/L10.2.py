import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path
from multiprocessing import Pool, cpu_count
import os
import time

def load_fasta(file_path):
    sequences = {}
    with open(file_path) as f:
        seq_id, seq = None, []
        for line in f:
            line = line.strip()
            if line.startswith(">"):
                if seq_id:
                    sequences[seq_id] = ''.join(seq)
                seq_id = line[1:]
                seq = []
            else:
                seq.append(line.upper())
        if seq_id:
            sequences[seq_id] = ''.join(seq)
    return sequences

def cg_content(seq):
    return (seq.count('C') + seq.count('G')) / len(seq) * 100

def index_of_coincidence(seq):
    n = len(seq)
    if n == 0: return 0
    counts = [seq.count(nuc) for nuc in "ACGT"]
    expected = n / 4
    return sum((c - expected)**2 / expected for c in counts)

def sliding_window(seq, win=30):
    cg_vals, ic_vals = [], []
    for i in range(len(seq) - win + 1):
        w = seq[i:i+win]
        cg_vals.append(cg_content(w))
        ic_vals.append(index_of_coincidence(w))
    return cg_vals, ic_vals

def center_of_weight(cg_vals, ic_vals):
    weights = np.arange(1, len(cg_vals)+1)
    return np.average(cg_vals, weights=weights), np.mean(ic_vals)

def plot_sequence_student(cg_vals, ic_vals, title, fname):
    """Student-style two-panel plot"""
    fig, axs = plt.subplots(1, 2, figsize=(14,6))
    
    axs[0].scatter(cg_vals, ic_vals, c='blue', edgecolor='k', s=80)
    axs[0].set_xlabel('C+G%')
    axs[0].set_ylabel('Kappa Index of Coincidence (IC)')
    axs[0].set_title(f"{title}: C+G% vs IC")
    axs[0].grid(True)
    
    center = np.mean(cg_vals) 
    axs[1].scatter([1], [center], c='red', edgecolor='k', s=200)
    axs[1].set_xlim(0,2)
    axs[1].set_ylabel('Center of Weight (CG%)')
    axs[1].set_title(f"{title}: Center of Weight")
    axs[1].set_xticks([])
    axs[1].grid(True)
    
    plt.tight_layout()
    plt.savefig(fname, dpi=300)
    plt.close()

def plot_all_centers_student(results, out_file):
    centers_cg = [r['center'][0] for r in results]
    centers_ic = [r['center'][1] for r in results]
    plt.figure(figsize=(12,8))
    plt.scatter(centers_cg, centers_ic, c='blue', s=50, edgecolor='k', alpha=0.6)
    plt.xlabel("C+G%")
    plt.ylabel("Kappa IC")
    plt.title("Centers of Weight - All Sequences")
    plt.grid(alpha=0.3)
    plt.tight_layout()
    plt.savefig(out_file, dpi=300)
    plt.close()

def plot_combined_obs_student(results, fname):
    all_cg, all_ic = [], []
    for r in results:
        all_cg.extend(r['cg'])
        all_ic.extend(r['ic'])
    plt.figure(figsize=(12,8))
    plt.scatter(all_cg, all_ic, c='blue', s=5, alpha=0.6, edgecolors='none')
    plt.xlabel("C+G%")
    plt.ylabel("Kappa IC")
    plt.title("Objective Digital Stain (OBS) - All Sequences")
    plt.grid(alpha=0.3)
    plt.tight_layout()
    plt.savefig(fname, dpi=300)
    plt.close()

def analyze_seq_student(args):
    idx, seq_id, seq, win, out_dir = args
    if len(seq) < win: return None
    cg_vals, ic_vals = sliding_window(seq, win)
    cg_c, ic_c = center_of_weight(cg_vals, ic_vals)
    out_file = os.path.join(out_dir, f"seq_{idx:04d}.png")
    plot_sequence_student(cg_vals, ic_vals, f"Seq {idx}: {seq_id[:50]}", out_file)
    return {'idx': idx, 'id': seq_id, 'cg': cg_vals, 'ic': ic_vals, 'center': (cg_c, ic_c), 'file': out_file}

def run_analysis_student(fasta_file, win=30, out_dir="dna_patterns", cores=None):
    Path(out_dir).mkdir(exist_ok=True)
    seqs = load_fasta(fasta_file)
    if not cores: cores = cpu_count()
    
    args_list = [(i+1, k, v, win, out_dir) for i,(k,v) in enumerate(seqs.items())]
    start = time.time()
    results = []
    with Pool(cores) as p:
        for i, r in enumerate(p.imap_unordered(analyze_seq_student, args_list), 1):
            if r: results.append(r)
            if i % 100 == 0: print(f"{i}/{len(args_list)} sequences processed...")
    elapsed = time.time() - start
    print(f"Done in {elapsed:.2f}s - {len(results)} sequences processed.")
    
    # Plots
    plot_all_centers_student(results, os.path.join(out_dir, "all_centers.png"))
    plot_combined_obs_student(results, os.path.join(out_dir, "OBS_final.png"))
    
    # Summary
    with open(os.path.join(out_dir,"summary.txt"), "w") as f:
        f.write(f"Sequences: {len(results)}\nWindow size: {win}\nTime: {elapsed:.2f}s\n")
        for r in results:
            f.write(f"{r['idx']}: {r['id']} CG:{np.mean(r['cg']):.2f} IC:{np.mean(r['ic']):.2f}\n")
    print(f"✓ Summary saved in {out_dir}/summary.txt")

if __name__ == "__main__":
    fasta_file = os.path.join(os.path.dirname(__file__), "promoters.fasta")
    if not os.path.exists(fasta_file):
        print("Error: 'promoters.fasta' not found in this folder!"); exit(1)
    run_analysis_student(fasta_file)
