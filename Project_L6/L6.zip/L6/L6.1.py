import random
import matplotlib.pyplot as plt


# Step 1: Read DNA sequence from FASTA file

def read_fasta(file_path):
    with open(file_path, 'r') as f:
        lines = f.readlines()
    sequence = ''.join(line.strip() for line in lines if not line.startswith('>'))
    return sequence

dna_sequence = read_fasta('sequence.fasta')
print(f"DNA sequence length: {len(dna_sequence)}")


# Step 2: Take 10 random samples
samples = []
fragment_lengths = []

for _ in range(10):
    max_fragment_len = min(3000, len(dna_sequence)-100)
    fragment_len = random.randint(100, max_fragment_len)
    start = random.randint(0, len(dna_sequence)-fragment_len)
    end = start + fragment_len
    fragment = dna_sequence[start:end]
    samples.append(fragment)
    fragment_lengths.append(len(fragment))

print("Fragment lengths:", fragment_lengths)

# Step 3: Map fragment sizes to y-axis positions
y_bp_positions = {100: 1, 500: 3, 1500: 6, 3000: 10}

min_bp, max_bp = 100, 3000
min_y, max_y = 1, 10
y_positions = [min_y + (frag - min_bp) / (max_bp - min_bp) * (max_y - min_y) for frag in fragment_lengths]


# Step 4: Plot horizontal bands like a gel ladder
plt.figure(figsize=(6,8))
line_length = 5
x_start = 2
x_end = x_start + line_length

for i, frag_len in enumerate(fragment_lengths):
    y_center = y_positions[i]
    plt.hlines(y=y_center, xmin=x_start, xmax=x_end, color='blue', linewidth=6)
    plt.text(x_end + 0.2, y_center, f"{frag_len} bp", va='center')

plt.yticks([y_bp_positions[bp] for bp in y_bp_positions.keys()],
           [f"{bp} bp" for bp in y_bp_positions.keys()])

plt.xticks([])
plt.ylim(0, 11)
plt.xlim(0, line_length + 4)
plt.ylabel("Fragment Size")
plt.title("DNA Gel Electrophoresis Simulation")
plt.gca().invert_xaxis()
plt.show()
