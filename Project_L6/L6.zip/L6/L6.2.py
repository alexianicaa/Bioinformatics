import matplotlib.pyplot as plt
import numpy as np


# Step 1: Read DNA sequence from FASTA file
def read_fasta(file_path):
    with open(file_path, 'r') as f:
        lines = f.readlines()
    sequence = ''.join(line.strip() for line in lines if not line.startswith('>'))
    return sequence

dna_sequence = read_fasta('sequence.fasta')
print(f"DNA sequence length: {len(dna_sequence)}")


# Step 2: Define 5 restriction enzymes
enzymes = {
    "EcoRI": "GAATTC",
    "BamHI": "GGATCC",
    "HindIII": "AAGCTT",
    "NotI": "GCGGCCGC",
    "XhoI": "CTCGAG"
}


# Step 3: Digest DNA with all 5 enzymes
cut_positions = set()  # store all cut positions

for enzyme, recog in enzymes.items():
    start = 0
    while True:
        pos = dna_sequence.find(recog, start)
        if pos == -1:
            break
        cut_positions.add(pos + len(recog))  # cut after recognition site
        start = pos + 1

# Sort cut positions
cut_positions = sorted(list(cut_positions))

# Generate fragments
fragments = []
prev = 0
for cut in cut_positions:
    fragments.append(dna_sequence[prev:cut])
    prev = cut
fragments.append(dna_sequence[prev:])  # last fragment

fragment_lengths = [len(frag) for frag in fragments]
print("Fragment lengths after digestion:", fragment_lengths)


# Step 4: Plot horizontal bands like a gel ladder
# Map fragment sizes to y-axis
min_bp, max_bp = 50, 3000
min_y, max_y = 1, 10
y_positions = [min_y + (min(frag, max_bp) - min_bp) / (max_bp - min_bp) * (max_y - min_y)
               for frag in fragment_lengths]

plt.figure(figsize=(6,8))
line_length = 5
x_start = 2
x_end = x_start + line_length

for i, frag_len in enumerate(fragment_lengths):
    y_center = y_positions[i]
    plt.hlines(y=y_center, xmin=x_start, xmax=x_end, color='blue', linewidth=6)
    plt.text(x_end + 0.2, y_center, f"{frag_len} bp", va='center')

plt.yticks([1, 3, 6, 10], ["100 bp", "500 bp", "1500 bp", "3000 bp"])
plt.xticks([])
plt.ylim(0, 11)
plt.xlim(0, line_length + 4)
plt.ylabel("Fragment Size")
plt.title("DNA Fragment Ladder After Multi-Enzyme Digestion (5 Enzymes)")
plt.gca().invert_xaxis()
plt.show()
