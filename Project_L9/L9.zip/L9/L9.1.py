import re
import matplotlib.pyplot as plt

# Restriction enzymes and their recognition sites
enzymes = {
    "EcoRI":   {"sequence": "GAATTC", "cleavage": 1},
    "BamHI":   {"sequence": "GGATCC", "cleavage": 1},
    "HindIII": {"sequence": "AAGCTT", "cleavage": 1},
    "TaqI":    {"sequence": "TCGA",   "cleavage": 1},
    "HaeIII":  {"sequence": "GGCC",   "cleavage": 2}
}

# Find cleavage sites for one enzyme
def findCleavageSites(dnaSeq, enzyme):
    recog = enzyme["sequence"]
    offset = enzyme["cleavage"]
    matches = re.finditer(f"(?={recog})", dnaSeq)
    return [m.start() + offset for m in matches]

# Digest using all enzymes
def digestDna(dnaSeq, enzymes):
    result = {}

    for name, enzyme in enzymes.items():
        cuts = findCleavageSites(dnaSeq, enzyme)
        points = [0] + sorted(cuts) + [len(dnaSeq)]

        sizes = []
        for i in range(len(points) - 1):
            sizes.append(points[i+1] - points[i])

        result[name] = {
            "cuts": cuts,
            "sizes": sorted(sizes, reverse=True)
        }

    return result

# Gel electrophoresis simulation
def plotGel(data):
    plt.figure(figsize=(6, 10))
    ax = plt.gca()
    ax.set_facecolor("black")

    laneSpacing = 3
    bandWidth = 0.8
    gelHeight = 500

    allSizes = [s for info in data.values() for s in info["sizes"]]
    if not allSizes:
        print("No fragments to plot.")
        return

    maxBp = max(allSizes)
    minBp = min(allSizes)
    span = maxBp - minBp if maxBp != minBp else 1

    def migration(bp):
        return 30 + (1 - (bp - minBp) / span) * gelHeight

    for i, (name, info) in enumerate(data.items()):
        x = 2 + i * laneSpacing
        plt.hlines(20, x - 0.6, x + 0.6, color="white", linewidth=6)

        for size in info["sizes"]:
            y = migration(size)
            plt.hlines(y, x - bandWidth/2, x + bandWidth/2, color="white", linewidth=4)

        plt.text(x, 10, name, color="white", ha="center", fontsize=9)

    plt.xlim(0, laneSpacing * (len(data) + 1))
    plt.ylim(0, gelHeight + 80)
    ax.invert_yaxis()
    plt.xticks([])
    plt.yticks([])
    plt.title("Restriction Digest Gel", color="white")
    plt.tight_layout()
    plt.show()

# ------------------

try:
    with open("sequence.fasta", "r") as f:
        dnaSeq = "".join(
            line.strip() for line in f
            if not line.startswith(">")
        ).upper()

    print("Sequence loaded. Length:", len(dnaSeq), "bp")

    fragments = digestDna(dnaSeq, enzymes)

    for name, info in fragments.items():
        print("\n" + name)
        print("  Cuts:", info["cuts"])
        print("  Fragments:", info["sizes"])

    plotGel(fragments)

except FileNotFoundError:
    print("sequence.fasta not found.")
