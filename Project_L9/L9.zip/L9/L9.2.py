import re
import matplotlib.pyplot as plt
import os

# Restriction enzymes
enzymes = {
    "EcoRI":   {"sequence": "GAATTC", "cleavage": 1},
    "BamHI":   {"sequence": "GGATCC", "cleavage": 1},
    "HindIII": {"sequence": "AAGCTT", "cleavage": 1},
    "TaqI":    {"sequence": "TCGA",   "cleavage": 1},
    "HaeIII":  {"sequence": "GGCC",   "cleavage": 2}
}

# Find cleavage sites
def findCleavageSites(seq, enzyme):
    recog = enzyme["sequence"]
    offset = enzyme["cleavage"]
    matches = re.finditer(f"(?={recog})", seq)
    return [m.start() + offset for m in matches]

# Digest a genome with all enzymes
def digestDna(seq, enzymes):
    result = {}
    for name, enzyme in enzymes.items():
        cuts = findCleavageSites(seq, enzyme)
        points = [0] + sorted(cuts) + [len(seq)]
        sizes = [points[i+1] - points[i] for i in range(len(points)-1)]
        result[name] = sorted(sizes, reverse=True)
    return result

# Gel plotting (single subplot per genome)
def plotGelsSubplots(gels, titles):
    n = len(gels)
    fig, axes = plt.subplots(1, n, figsize=(3*n, 10), sharey=True)
    if n == 1:
        axes = [axes]

    gelHeight = 600
    bandWidth = 0.8
    laneSpacing = 1

    # find global min/max for scaling
    all_sizes = [b for g in gels for sizes in g.values() for b in sizes]
    maxBp = max(all_sizes)
    minBp = min(all_sizes)
    span = maxBp - minBp if maxBp != minBp else 1

    def migration(bp):
        return 40 + (1 - (bp - minBp) / span) * gelHeight

    for idx, gelData in enumerate(gels):
        ax = axes[idx]
        ax.set_facecolor("black")
        ax.set_xticks([])
        ax.set_yticks([])
        ax.set_xlim(0, laneSpacing * len(gelData))
        ax.set_ylim(0, gelHeight + 50)
        ax.invert_yaxis()

        for i, (enzyme, sizes) in enumerate(gelData.items()):
            x = i * laneSpacing
            ax.hlines(20, x - 0.3, x + 0.3, color="white", linewidth=6)
            for s in sizes:
                y = migration(s)
                ax.hlines(y, x - bandWidth/2, x + bandWidth/2, color="white", linewidth=3)
            ax.text(x, 10, enzyme, color="white", ha="center", fontsize=8)

        ax.set_title(titles[idx], color="white", fontsize=9)

    plt.suptitle("Electrophoresis Gels (Differences Only) for Influenza Variants", color="black")
    plt.tight_layout()
    plt.show()

# ------------------------------
# MAIN PROCESSING
# ------------------------------
folder = "influenza"
files = sorted([f for f in os.listdir(folder) if f.endswith(".fasta")])

all_genomes = {}
all_gels = {}

# Load genomes & generate normal gels
for f in files:
    path = os.path.join(folder, f)
    with open(path) as fh:
        seq = "".join(line.strip() for line in fh if not line.startswith(">")).upper()
    all_genomes[f] = seq
    all_gels[f] = digestDna(seq, enzymes)

# Find common bands across all genomes
common_bands = {}
for enzyme in enzymes.keys():
    sets = [set(all_gels[g][enzyme]) for g in all_gels]
    common_bands[enzyme] = set.intersection(*sets)

# Remove common bands → keep only differences
difference_gels = {}
for gname, gel in all_gels.items():
    difference_gels[gname] = {}
    for enzyme in enzymes.keys():
        unique_bands = [b for b in gel[enzyme] if b not in common_bands[enzyme]]
        difference_gels[gname][enzyme] = unique_bands

# Plot all difference gels in one figure with subplots
plotGelsSubplots(list(difference_gels.values()), list(difference_gels.keys()))

# Merge all difference gels into one final gel (unique bands per enzyme)
merged = {}
for enzymes_gel in difference_gels.values():
    for enzyme, bands in enzymes_gel.items():
        merged.setdefault(enzyme, set()).update(bands)  # unique bands only

# Convert sets back to sorted lists
for enzyme in merged:
    merged[enzyme] = sorted(merged[enzyme], reverse=True)

# Plot merged gel
plotGelsSubplots([merged], ["Merged Gel – Differences Between All Influenza Variants"])
