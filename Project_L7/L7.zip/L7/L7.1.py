from Bio import SeqIO
from collections import Counter
import matplotlib.pyplot as plt
import os

def load_fasta_sequence(file_path):
    """Load DNA sequence from FASTA file."""
    record = next(SeqIO.parse(file_path, "fasta"))
    return str(record.seq).upper()

def find_tandem_repeats(sequence, min_len, max_len, min_repeats):
    """
    Find motifs repeated consecutively at least min_repeats times.
    Returns a Counter of motifs with the number of tandem blocks.
    """
    n = len(sequence)
    repeats = Counter()

    for size in range(min_len, max_len + 1):
        i = 0
        while i <= n - size:
            motif = sequence[i:i+size]
            count = 1
            j = i + size
            while j + size <= n and sequence[j:j+size] == motif:
                count += 1
                j += size
            if count >= min_repeats:
                # increment for each tandem block found
                repeats[motif] += 1
                i = j
            else:
                i += 1
    return repeats

def main():
    folder = "."  # change to your FASTA folder path
    files = sorted([f for f in os.listdir(folder) if f.endswith(".fasta")])

    if len(files) < 10:
        print(f"⚠️ Expected 10 FASTA files, found {len(files)} in '{folder}'")
    
    min_len, max_len, min_repeats = 6, 10, 2
    all_repeats_dict = {}


    # 1. Individual subplot grid
    fig, axes = plt.subplots(2, 5, figsize=(20, 8))
    axes = axes.flatten()

    for i, file in enumerate(files):
        path = os.path.join(folder, file)
        seq = load_fasta_sequence(path)
        print(f"\nAnalyzing {file} (length = {len(seq)} bases)")
        
        repetitions = find_tandem_repeats(seq, min_len=min_len, max_len=max_len, min_repeats=min_repeats)
        title = file.replace(".fasta", "")
        all_repeats_dict[title] = repetitions

        ax = axes[i]
        if repetitions:
            patterns = list(repetitions.keys())
            counts = list(repetitions.values())
            ax.bar(range(len(patterns)), counts, color="skyblue", edgecolor="black")
            ax.set_xticks(range(len(patterns)))
            ax.set_xticklabels(patterns, rotation=90, fontsize=6)
            ax.set_ylabel("Repeats", fontsize=8)   # fixed label
            ax.set_xlabel("Pattern", fontsize=8)   # fixed label
        else:
            ax.text(0.5, 0.5, "No repetitions", ha='center', va='center', fontsize=9)

        ax.set_title(title, fontsize=10)

    plt.tight_layout()
    plt.suptitle("Tandem Repeat Frequencies (Individual Sequences)", fontsize=14, y=1.02)
    plt.show()

    # 2. Combined colorful chart
    all_motifs = sorted(set().union(*[repeats.keys() for repeats in all_repeats_dict.values()]))
    x = range(len(all_motifs))
    width = 0.8 / len(all_repeats_dict)

    plt.figure(figsize=(14, 6))
    for idx, (seq_name, repeats) in enumerate(all_repeats_dict.items()):
        counts = [repeats.get(motif, 0) for motif in all_motifs]
        plt.bar([pos + idx*width for pos in x], counts, width=width, label=seq_name)

    plt.xticks([pos + width*(len(all_repeats_dict)/2) for pos in x], all_motifs, rotation=90)
    plt.title(f"Comparison of Tandem Repeats Across Sequences (≥{min_repeats} repeats)")
    plt.xlabel(f"Motif ({min_len}–{max_len} bases)")
    plt.ylabel("Repeats")   # fixed label
    plt.legend()
    plt.tight_layout()
    plt.show()

if __name__ == "__main__":
    main()
